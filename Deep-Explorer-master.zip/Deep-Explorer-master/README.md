# Deep Explorer
<a href="https://asciinema.org/a/DFmZ61APHIZnwfXFHn4sAxfJm" target="_blank"><img src="https://asciinema.org/a/DFmZ61APHIZnwfXFHn4sAxfJm.svg" /></a>
# Dependencies
     pip install -r requirements.txt
also you should have Tor installed    
# Usage

python deepexplorer.py STRING_TO_SEARCH NUMBER_OF_RESULTS TYPE_OF_CRAWL

Examples:

python deepexplorer.py "legal thing" 40 default (will crawl if results obtained in browser do not reach 40)

python deepexplorer.py "legal thing" 30 all (will crawl every link obtained in browser [ultil reachs 30])

python deepexplorer.py "legal thing" 30 none (do not crawl, only obtain links from browser)


# About
Deep Explorer is a tool designed to search (any) thing in a few seconds

Any idea, failure etc please report to telegram: blueudp

results.txt contains results obtaioned in previus search

Tested in ParrotOS and Kali Linux 2.0

# Type of Errors
+ Error importing... -> You should try manual pip install package
+ Error connecting to server -> Cant connect to ahmia browser
# Is this illegal?
It depends, Deep Explorer is not designed with the purpose of searching illegal things, remember that Tor it's a simple network

# Contact Me
Name: Eduardo Pérez-Malumbres

Telegram: @blueudp

Twitter: https://twitter.com/blueudp
