# Examples have been moved!

If you're searching for Haystack examples we moved them into a dedicated repository.

You can find all the example cookbooks [👉 here 👈](https://github.com/deepset-ai/haystack-cookbook/).
